package net.razboy.pong;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.geometry.Bounds;

import net.razboy.pong.Physics;

public class App extends Application {
  
  private Scene pongScene;
  private Group root;
  private Rectangle paddleLeft; 
  private Rectangle paddleRight;
  private Rectangle wallTop;
  private Rectangle wallBottom;
  private Rectangle ball;
  
  public void start(Stage primaryStage) throws Exception {
    System.out.println("Started!");
    root = new Group();
    
    paddleLeft = new Rectangle(15,600/2-150/2,22,150);
    paddleLeft.setFill(Color.WHITE);
    
    paddleRight = new Rectangle(1000-22-15,600/2-150/2,22,150);
    paddleRight.setFill(Color.WHITE);
    
    wallBottom = new Rectangle(0,-50,1000,50);
    
    wallTop = new Rectangle(0,600,1000,50);
    
    
    root.getChildren().add(paddleLeft);
    root.getChildren().add(paddleRight);
    root.getChildren().add(wallTop);
    root.getChildren().add(wallBottom);
    pongScene = new Scene(root,1000-10,600-10);
    pongScene.setFill(Color.BLACK);
    
 
    Physics pongPhysics = new Physics();
    
    
    AnimationTimer gameTick = new AnimationTimer() {
      public void handle(long now) {
        pongPhysics.run(pongScene, paddleLeft, paddleRight, ball, wallTop, wallBottom);
        pongPhysics.convertToRect();
      }
    };
    primaryStage.setTitle("Pong");
    primaryStage.setResizable(false);
    primaryStage.setScene(pongScene);
    primaryStage.show(); 
    gameTick.start();
    
  }
  
  public static void main(String[] args) { 
    launch(args);
  }
  
}