package net.razboy.pong;

import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.geometry.Bounds;


public class Physics {
  int rightPaddleVY = 0;
  int leftPaddleVY = 0;
  int rightPaddleVX = 0;
  int leftPaddleVX = 0;
  
  int paddlespeed = 6;
  
  double ballX = 0;
  double ballY = 0;
  double ballVY = 0;
  double ballVX = 0;
  double ballDirection = 90;
  double ballSpeed = 1;
  
  public void convertToPolar() {
    // converts ball vx and vy to polar coordinates.
  }
  
  public void convertToRect() {
    // converts ball direction and speed to rectangular coordinates.
    ballVX = Math.sin(Math.toRadians(ballDirection))*ballSpeed;
    ballVY = Math.cos(Math.toRadians(ballDirection))*ballSpeed;
    System.out.println(ballVX+" -- "+ballVY);
  }
  
  public void run(Scene pongScene, Rectangle leftPaddle, Rectangle rightPaddle, Rectangle ball, Rectangle wallBottom, Rectangle wallTop) {
    // move paddles on keypresses
    pongScene.setOnKeyPressed(x -> {
      switch (x.getCode()) {
        case UP:
          rightPaddleVY = paddlespeed*-1;
          break;
        case DOWN:
          rightPaddleVY = paddlespeed;
          break;
        case W:
          leftPaddleVY = paddlespeed*-1;
          break;
        case S:
          leftPaddleVY = paddlespeed;
          break;
        default:
          break;
      }
    });
    pongScene.setOnKeyReleased(x -> {
      switch (x.getCode()) {
        case UP:
          rightPaddleVY = 0;
          break;
        case DOWN:
          rightPaddleVY = 0;
          break;
        case W:
          leftPaddleVY = 0;
          break;
        case S:
          leftPaddleVY = 0;
          break;
        default:
          break;
      }
      
      
    });
    leftPaddle.setY(leftPaddle.getY()+leftPaddleVY);
    rightPaddle.setY(rightPaddle.getY()+rightPaddleVY);
    
    // paddle collision with walls (so stop movement etc...)
    
    Bounds topWallBounds = wallTop.getBoundsInParent();
    Bounds bottomWallBounds = wallBottom.getBoundsInParent();
    Bounds rightPaddleBounds = rightPaddle.getBoundsInParent();
    Bounds leftPaddleBounds = leftPaddle.getBoundsInParent();
    
    if (rightPaddleBounds.intersects(topWallBounds)) {
      rightPaddle.setY(wallTop.getY() + wallTop.getHeight() + 0.01);
    } else if (rightPaddleBounds.intersects(bottomWallBounds)) {
      rightPaddle.setY(bottomWallBounds.getMinY() - rightPaddle.getHeight() - 0.01);
    }
    
    if (leftPaddleBounds.intersects(topWallBounds)) {
      leftPaddle.setY(wallTop.getY() + wallTop.getHeight() + 0.01);
    } else if (leftPaddleBounds.intersects(bottomWallBounds)) {
      leftPaddle.setY(bottomWallBounds.getMinY() - leftPaddle.getHeight() - 0.01);
    }
    
    
  }
}
