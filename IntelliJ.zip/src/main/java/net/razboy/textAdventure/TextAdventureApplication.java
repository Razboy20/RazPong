package net.razboy.textAdventure;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class TextAdventureApplication extends Application {

 public static final int RESOLUTION_WIDTH = 800;
 public static final int RESOLUTION_HEIGHT = 600;

 public static final String FONT_NAME = "Arial";

 public static final Font BIG_FONT = new Font(FONT_NAME, 32);
 public static final Font SMALL_FONT = new Font(FONT_NAME, 18);

 private Stage primaryStage;

 @Override
 public void init() throws Exception {
  super.init();
 }

 @Override
 public void start(Stage primaryStage) throws Exception {
  this.primaryStage = primaryStage;

  primaryStage.setTitle("Elie's Text Adventure");
  primaryStage.setResizable(false);
  primaryStage.show();
//  primaryStage.setScene(new WelcomeScene(this));
  

 }

 @Override
 public void stop() throws Exception {
  super.stop();
 }


 public static void main(String args[]) {
  launch(args);
 }

}

