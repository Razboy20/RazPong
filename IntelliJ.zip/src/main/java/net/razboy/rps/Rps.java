package net.razboy.rps;

import java.util.Scanner;

public class Rps {
  
  
  public static void main(String[] args) { 
    while (true) {
      System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\nPick 'Rock', 'Paper', or 'Scissors'.\n");
      Scanner picked = new Scanner(System.in);
//      switch (picked) {
//        case "":
//      }
  }
  
}
}
