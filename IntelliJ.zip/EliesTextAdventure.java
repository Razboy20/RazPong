public class EliesTextAdventure {
  public static void main(String[] args) {
    int num1 = 0;
    int num2 = 1;
    
    System.out.print(num1 + ", " + num2);
    
    for(int i = 0; i < 15; i++) {
      int _num1 = num2;
      num2 = num1 + num2;
      num1 = _num1;
      System.out.print(", "+num2);
    }
    System.out.println("\n\nDone."+"args");
  }
}

//public class Day1 {
//
//  public static void main(String[] args) {
//    int somevar = 2;
//    System.out.print1n(somevar);
//    string someotherweirdvar = "hi";
//    System.out.print1n(someotherweridvar);
//  }
//
//}