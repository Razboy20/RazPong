package net.razboy.pong;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.stage.WindowEvent;
import javafx.event.EventHandler;
import javafx.application.Platform;

import net.razboy.pong.Physics;
import net.razboy.pong.Scores;

public class App extends Application {

    private App thisApp = this;

    public Scene pongScene;
    public Group root;
    public Rectangle paddleLeft;
    public Rectangle paddleRight;
    public Rectangle wallTop;
    public Rectangle wallBottom;
    public Rectangle ball;
    public Rectangle endGameLeft;
    public Rectangle endGameRight;

    public Rectangle comedyPongPaddleLeft = new Rectangle(15, 0, 22, 600);


    public Scores scoreBox;
    public Stage scoreStage;


    @Override
    public void start(Stage primaryStage) throws Exception {
        System.out.println("Started!");
        root = new Group();

        paddleLeft = new Rectangle(15,600/2-150/2,22,150);
        paddleLeft.setFill(Color.WHITE);

        paddleRight = new Rectangle(1000-22-15,600/2-150/2,22,150);
        paddleRight.setFill(Color.WHITE);

        ball = new Rectangle(1000/2-15/2,600/2-15/2,15,15);
        ball.setFill(Color.WHITE);

        wallTop = new Rectangle(0,-50,1000,50);

        wallBottom = new Rectangle(0,600,1000,50);

        endGameLeft = new Rectangle(-50,0,50,600);

        endGameRight = new Rectangle(1000,0,50,600);

        comedyPongPaddleLeft.setFill(Color.WHITE);


        root.getChildren().add(paddleLeft);
        root.getChildren().add(paddleRight);
        root.getChildren().add(wallTop);
        root.getChildren().add(wallBottom);
        root.getChildren().add(ball);
        pongScene = new Scene(root,1000-10,600-10);
        pongScene.setFill(Color.BLACK);

        scoreStage = new Stage();
        scoreBox = new Scores();

        Physics pongPhysics = new Physics();
        pongPhysics.convertToRect();

        AnimationTimer gameTick = new AnimationTimer() {
            public void handle(long now) {
                if (pongPhysics.shouldReset) pongPhysics.resetGame(paddleLeft, paddleRight, ball);

//                scoreText.setText("Player 1 Score: " + pongPhysics.player1Score + " -- Player 2 Score: " + pongPhysics.player2Score);
                scoreBox.updateScore(pongPhysics.player1Score, pongPhysics.player2Score);

                if (pongPhysics.countDown <= 0) {
                    pongPhysics.run(thisApp);
                }

                if (pongPhysics.countDown > 0) pongPhysics.countDown -=1;
            }
        };
        primaryStage.setTitle("Pong");
        primaryStage.setResizable(false);
        primaryStage.setScene(pongScene);
        primaryStage.show();
        primaryStage.setX(primaryStage.getX() - 75);
        primaryStage.setY(primaryStage.getY() - 0);

        scoreStage.setX(primaryStage.getX() + primaryStage.getWidth() + 30);
        scoreStage.setY(primaryStage.getY() + 75);
        scoreBox.start(scoreStage);

        if (pongPhysics.comedyPong) {
            comedyPongPaddleLeft.setVisible(false);
            root.getChildren().add(comedyPongPaddleLeft);
        }

        primaryStage.requestFocus();
        gameTick.start();


        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });
    }


    public static void main(String[] args) {
        launch(args);
    }

}