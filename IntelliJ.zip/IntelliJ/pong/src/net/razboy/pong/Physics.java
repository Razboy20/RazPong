package net.razboy.pong;

import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.geometry.Bounds;

import net.razboy.pong.App;


public class Physics {
    private int rightPaddleVY = 0;
    private int leftPaddleVY = 0;

    private int paddlespeed = 6;
    public int countDown = 0;
    public boolean shouldReset = true;

    public int player1Score = 0;
    public int player2Score = 0;

    private double ballVY = 3;
    private double ballVX = 3;
    private double ballDirection = 0;
    private double ballSpeed = 5;
    private double initialBallSpeed = 5;
    private double ballSpeedIncrease = 1.2;

    private double ballGravity = 0;
    private double ballGravitySpeed = 0.2;


    // COMEDY PONG
    public boolean comedyPong = true;

    private boolean comedyPongStage[] = new boolean[] {false, false, false, false, false, false, false, false};
    // COMEDY PONG

    public void resetGame(Rectangle leftPaddle, Rectangle rightPaddle, Rectangle ball) {
        countDown = 150;
        shouldReset = false;
        ballSpeed = initialBallSpeed;

        leftPaddle.setY(600/2-150/2);
        rightPaddle.setY(600/2-150/2);
        ball.setY(600/2-15/2);
        ball.setX(1000/2-15/2);

        ballDirection = Math.random() * 360;
        while (!(ballDirection < 60 || (ballDirection > 120 && ballDirection < 240) || ballDirection > 300)) {
            ballDirection = Math.random() * 360;
        }
//        System.out.println(ballDirection);
        convertToRect();
    }

    public void convertToPolar() {
        // converts ball vx and vy to polar coordinates.
        double tempRadian = Math.atan2(ballVY,ballVX);
        if (tempRadian < 0) tempRadian = (2*Math.PI + tempRadian) % (2*Math.PI);
        ballDirection = Math.toDegrees(tempRadian);
        ballSpeed = Math.hypot(ballVX,ballVY);
        System.out.println("Polar -- direction: " + ballDirection + " -- speed: "+ballSpeed);
    }

    public void convertToRect() {
        // converts ball direction and speed to rectangular coordinates.
        ballVX = Math.sin(Math.toRadians(ballDirection*-1+90))*ballSpeed;
        ballVY = Math.cos(Math.toRadians(ballDirection*-1+90))*ballSpeed;
        System.out.println("Rect -- vx: "+ballVX+" -- vy: "+ballVY);
    }

    public void run(App pongApp) {

        Scene pongScene = pongApp.pongScene;
        Rectangle leftPaddle = pongApp.paddleLeft;
        Rectangle rightPaddle = pongApp.paddleRight;
        Rectangle ball = pongApp.ball;
        Rectangle wallBottom = pongApp.wallBottom;
        Rectangle wallTop = pongApp.wallTop;
        Rectangle endGameLeft = pongApp.endGameLeft;
        Rectangle endGameRight = pongApp.endGameRight;

        // move paddles on key presses
        pongScene.setOnKeyPressed(x -> {
            switch (x.getCode()) {
                case UP:
                    rightPaddleVY = paddlespeed*-1;
                    break;
                case DOWN:
                    rightPaddleVY = paddlespeed;
                    break;
                case W:
                    leftPaddleVY = paddlespeed*-1;
                    break;
                case S:
                    leftPaddleVY = paddlespeed;
                    break;
                case G:
                    if (ballGravity == 0) ballGravity = ballGravitySpeed;
                    else ballGravity = 0;
                    break;
                // Comedy Pong
                case DIGIT1:
                    comedyPongStage[0] = true;
                    break;
                case DIGIT2:
                    comedyPongStage[1] = true;
                    leftPaddleVY = paddlespeed * -1;
                    break;
                case DIGIT3:
                    comedyPongStage[2] = true;
                    break;
                case DIGIT4:
                    comedyPongStage[3] = true;
                    break;
                case DIGIT5:
                    comedyPongStage[4] = true;
                    break;
                default:
                    break;
            }
        });
        pongScene.setOnKeyReleased(x -> {
            switch (x.getCode()) {
                case UP:
                case DOWN:
                    rightPaddleVY = 0;
                    break;
                case W:
                case S:
                    leftPaddleVY = 0;
                    break;
                default:
                    break;
            }


        });
        ballVY += ballGravity;

        leftPaddle.setY(leftPaddle.getY()+leftPaddleVY);
        rightPaddle.setY(rightPaddle.getY()+rightPaddleVY);
        ball.setX(ball.getX()+ballVX);
        ball.setY(ball.getY()+ballVY);

        // paddle collision with walls (so stop movement etc...)

        Bounds topWallBounds = wallTop.getBoundsInParent();
        Bounds bottomWallBounds = wallBottom.getBoundsInParent();
        Bounds rightPaddleBounds = rightPaddle.getBoundsInParent();
        Bounds leftPaddleBounds = leftPaddle.getBoundsInParent();
        Bounds ballBounds = ball.getBoundsInParent();
        Bounds leftGoalBounds = endGameLeft.getBoundsInParent();
        Bounds rightGoalBounds = endGameRight.getBoundsInParent();

        if (rightPaddleBounds.intersects(topWallBounds)) {
            rightPaddle.setY(wallTop.getY() + wallTop.getHeight() + 0.01);
        } else if (rightPaddleBounds.intersects(bottomWallBounds)) {
            rightPaddle.setY(bottomWallBounds.getMinY() - rightPaddle.getHeight() - 0.01);
        }

        if (leftPaddleBounds.intersects(topWallBounds)) {
            leftPaddle.setY(wallTop.getY() + wallTop.getHeight() + 0.01);
        } else if (leftPaddleBounds.intersects(bottomWallBounds)) {
            leftPaddle.setY(bottomWallBounds.getMinY() - leftPaddle.getHeight() - 0.01);
        }

        if (ballBounds.intersects(topWallBounds)) {
            ball.setY(wallTop.getY() + wallTop.getHeight() + 0.01);
            ballVY *= -1;
        }
        if (ballBounds.intersects(bottomWallBounds)) {
            ball.setY(bottomWallBounds.getMinY() - ball.getHeight() - 0.01);
            ballVY *= -1;
        }

        if (ballBounds.intersects(leftPaddleBounds)) {
            ball.setX(leftPaddleBounds.getMaxX() + 0.01);
            ballVX *= -1;
            convertToPolar();

            ballSpeed += ballSpeedIncrease;

            ballDirection += 90;
            if (ballDirection > 360) {
               ballDirection -= 360;
            }

            double ballDistance = ball.getY() - (leftPaddle.getY() + (leftPaddle.getHeight()/2) - ball.getHeight());
            double percentChange = (50 / (leftPaddle.getHeight() / 2)) * Math.abs(ballDistance) * 0.01;
            System.out.println(ballDistance + " -- " + percentChange + "%");

            if (ballDistance < 0) {
                ballDirection *= 1 - percentChange;
            } else {
                ballDirection = 180 - ballDirection;
                ballDirection *= 1 - percentChange;
                ballDirection = 180 - ballDirection;
            }

            if (ballDirection < 90) {
                ballDirection += 360;
            }
            ballDirection -= 90;

            convertToRect();
        }
        if (ballBounds.intersects(rightPaddleBounds)) {
            ball.setX(rightPaddle.getX() - ball.getWidth() - 0.01);
            ballVX *= -1;
            System.out.println("Debug -- vx: " + ballVX + " -- vy: " + ballVY);
            convertToPolar();

            ballSpeed += ballSpeedIncrease;

            ballDirection -= 90;

            double ballDistance = ball.getY() - (rightPaddle.getY() + (rightPaddle.getHeight()/2) - ball.getHeight());
            double percentChange = (50 / (rightPaddle.getHeight() / 2)) * Math.abs(ballDistance) * 0.01;
            System.out.println(ballDistance + " -- " + percentChange + "%");

            if (ballDistance > 0) {
                ballDirection *= 1 - percentChange;
            } else {
                ballDirection = 180 - ballDirection;
                ballDirection *= 1 - percentChange;
                ballDirection = 180 - ballDirection;
            }


            ballDirection += 90;

            convertToRect();
        }

        if (ballBounds.intersects(leftGoalBounds)) {
            shouldReset = true;
            player2Score++;
        }

        if (ballBounds.intersects(rightGoalBounds)) {
            shouldReset = true;
            player1Score++;
        }


        // Comedy Pong Stuff --- Can be turned off

        if (comedyPong) {
            if (comedyPongStage[0]) {
                double ballDistance = ball.getY() - (rightPaddle.getY() + (rightPaddle.getHeight()/2) - ball.getHeight());
                if (ballDistance > 20) {
                    rightPaddleVY = paddlespeed;
                }
                if (ballDistance < -20) {
                    rightPaddleVY = paddlespeed * -1;
                }

                if (ballDistance < 20 && ballDistance > -20) {
                    rightPaddleVY = 0;
                }

            }
            if (comedyPongStage[1]) {
                if (leftPaddleBounds.getMinY() < topWallBounds.getMaxY() + 1) {
                    leftPaddleVY *= -1;
                }
                if (leftPaddleBounds.getMaxY() > bottomWallBounds.getMinY() - 1) {
                    leftPaddleVY *= -1;
                }
                if (ballBounds.intersects(pongApp.comedyPongPaddleLeft.getBoundsInParent())) {
                    ball.setX(pongApp.comedyPongPaddleLeft.getBoundsInParent().getMaxX() + 0.01);
                    ballVX *= -1;
                }
                double ballDistance = ball.getX() - (rightPaddle.getX());
                if (ballDistance < 100) {
                    pongApp.comedyPongPaddleLeft.setVisible(true);
                } else {
                    pongApp.comedyPongPaddleLeft.setVisible(false);
                }
            }
            if (comedyPongStage[2]) {
                pongApp.comedyPongPaddleLeft.setVisible(true);
            }
        }

    }
}
