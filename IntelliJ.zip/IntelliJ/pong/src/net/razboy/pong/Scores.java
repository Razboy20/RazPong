package net.razboy.pong;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.*;

public class Scores extends Application {
    private Scene scoreScene;
    private StackPane scores;
    private Text scoreText;
    private Font pongFont;

    public void start(Stage primaryStage) throws Exception {
        pongFont = Font.loadFont(getClass().getResourceAsStream("/fonts/bit5x3.ttf"),130);

        scores = new StackPane();
        scoreText = new Text();
        scoreText.setFill(Color.BLACK);
        scoreText.setText("0\n\n\n0");
        scoreText.setFont(pongFont);
        scores.getChildren().add(scoreText);

        scoreScene = new Scene(scores,100-10,450-10);
        scoreScene.setFill(Color.WHITE);

        primaryStage.setTitle("Pong Scores");
        primaryStage.setResizable(false);
        primaryStage.setScene(scoreScene);
        primaryStage.show();
    }

    public void updateScore(int player1Score, int player2Score) {
        scoreText.setText(player1Score + "\n\n\n" + player2Score);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
